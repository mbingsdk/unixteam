'use client';

import Link from 'next/link';
import Image from 'next/image';
import { useState, useEffect } from 'react';
import { usePathname } from 'next/navigation';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Menu, X, Home, Info, Users, FolderGit2,
  BookOpen, FileText, HelpCircle, MessageCircle,
} from 'lucide-react';
import { DiscordIcon } from './ui/SocialIcons';

const navLinks = [
  { href: '/',              label: 'Home' },
  { href: '/about',         label: 'About' },
  { href: '/team',          label: 'Team' },
  { href: '/projects',      label: 'Projects' },
  { href: '/blog',          label: 'Blog' },
  // { href: '/discord', label: 'Discord' },
  // { href: '/server-status', label: 'Status', isStatus: true },
  { href: '/faq',           label: 'FAQ' },
  { href: '/documentation', label: 'Docs' },
];

const drawerLinks = [
  { href: '/',              label: 'Home',         icon: Home },
  { href: '/about',         label: 'About',        icon: Info },
  { href: '/team',          label: 'Team',         icon: Users },
  { href: '/projects',      label: 'Projects',     icon: FolderGit2 },
  { href: '/blog',          label: 'Blog',         icon: FileText },
  { href: '/faq',           label: 'FAQ',          icon: HelpCircle },
  { href: '/documentation', label: 'Docs',         icon: BookOpen },
];

export default function Navigation() {
  const [drawerOpen, setDrawerOpen]   = useState(false);
  const [scrolled,   setScrolled]     = useState(false);
  const pathname = usePathname();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  // Close drawer on route change
  useEffect(() => { setDrawerOpen(false); }, [pathname]);

  // Lock body scroll when drawer is open
  useEffect(() => {
    document.body.style.overflow = drawerOpen ? 'hidden' : '';
    return () => { document.body.style.overflow = ''; };
  }, [drawerOpen]);

  const isActive = (href: string) =>
    href === '/' ? pathname === '/' : pathname.startsWith(href);

  return (
    <>
      {/* ── Floating Pill ─────────────────────────────────────────── */}
      <motion.nav
        initial={{ opacity: 0, y: -16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, ease: 'easeOut' }}
        className={[
          'fixed top-4 left-1/2 -translate-x-1/2 z-50',
          'flex items-center gap-1',
          'rounded-full border border-border',
          'px-2 py-1.5',
          'transition-all duration-300',
          scrolled
            ? 'bg-foreground/15 backdrop-blur-md shadow-lg shadow-black/20'
            : 'bg-foreground/10 backdrop-blur-sm',
        ].join(' ')}
        style={{ maxWidth: 'calc(100vw - 2rem)' }}
      >
        {/* Logo */}
        <Link
          href="/"
          className="flex items-center gap-3 px-3 py-1 rounded-full hover:bg-white/5 transition-colors"
        >
          <div className="relative h-6 w-6 rounded-full overflow-hidden flex-shrink-0">
            <Image
              src="/apple-icon.png"
              alt="UNIX-TEAM"
              fill
              className="object-cover"
              priority
            />
          </div>
          <span className="font-bold text-sm text-foreground whitespace-nowrap">
            UNIX-TEAM
          </span>
        </Link>

        {/* Divider — desktop only */}
        <div className="hidden md:block w-px h-4 bg-border/60 mx-1 flex-shrink-0" />

        {/* Nav links — desktop only */}
        <div className="hidden md:flex items-center gap-0.5">
          {navLinks.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className={[
                'text-sm px-3 py-1.5 rounded-full transition-all duration-150',
                isActive(link.href)
                  ? 'bg-accent/15 text-accent font-medium'
                  : 'text-foreground/60 hover:text-foreground hover:bg-white/5',
              ].join(' ')}
            >
              {link.label}
            </Link>
          ))}
        </div>

        {/* Divider — desktop only */}
        <div className="hidden md:block w-px h-4 bg-border/60 mx-1 flex-shrink-0" />

        {/* Discord CTA — desktop */}
        <a
          href="https://discord.gg/unix-team"
          target="_blank"
          rel="noopener noreferrer"
          className="hidden md:inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full bg-accent text-brand-dark text-sm font-semibold hover:bg-accent/90 transition-colors flex-shrink-0"
        >
          <DiscordIcon size={14} />
          Discord
        </a>

        {/* Mobile: only hamburger */}
        <div className="flex md:hidden items-center ml-1">
          <button
            onClick={() => setDrawerOpen((v) => !v)}
            className="flex items-center justify-center w-8 h-8 rounded-full bg-white/5 hover:bg-white/10 transition-colors text-foreground/70 flex-shrink-0"
            aria-label="Toggle menu"
          >
            <AnimatePresence mode="wait" initial={false}>
              <motion.div
                key={drawerOpen ? 'x' : 'menu'}
                initial={{ rotate: -90, opacity: 0 }}
                animate={{ rotate: 0, opacity: 1 }}
                exit={{ rotate: 90, opacity: 0 }}
                transition={{ duration: 0.15 }}
              >
                {drawerOpen ? <X size={16} /> : <Menu size={16} />}
              </motion.div>
            </AnimatePresence>
          </button>
        </div>
      </motion.nav>

      {/* ── Mobile Drawer ──────────────────────────────────────────── */}
      <AnimatePresence>
        {drawerOpen && (
          <>
            {/* Backdrop */}
            <motion.div
              key="backdrop"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
              onClick={() => setDrawerOpen(false)}
              className="fixed inset-0 z-40 bg-black/40 backdrop-blur-sm md:hidden"
            />

            {/* Drawer panel */}
            <motion.div
              key="drawer"
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              transition={{ type: 'spring', damping: 28, stiffness: 300 }}
              className="fixed bottom-0 left-0 right-0 z-50 md:hidden"
            >
              <div className="bg-background border-t border-border/60 rounded-t-2xl overflow-hidden pb-safe">
                {/* Handle bar */}
                <div className="flex justify-center pt-3 pb-2">
                  <div className="w-9 h-1 rounded-full bg-border/60" />
                </div>

                {/* Nav items */}
                <nav className="px-3 pb-2">
                  {drawerLinks.map((link, i) => {
                    const Icon = link.icon;
                    const active = isActive(link.href);
                    return (
                      <motion.div
                        key={link.href}
                        initial={{ opacity: 0, x: -12 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: i * 0.04, duration: 0.2 }}
                      >
                        <Link
                          href={link.href}
                          className={[
                            'flex items-center gap-3 px-4 py-3 rounded-xl mb-0.5',
                            'text-[15px] font-medium transition-colors',
                            active
                              ? 'bg-accent/10 text-accent'
                              : 'text-foreground/70 hover:bg-white/5 hover:text-foreground',
                          ].join(' ')}
                        >
                          <Icon size={18} className="flex-shrink-0" />
                          {link.label}
                          {active && (
                            <div className="ml-auto w-1.5 h-1.5 rounded-full bg-accent" />
                          )}
                        </Link>
                      </motion.div>
                    );
                  })}
                </nav>

                {/* Discord CTA */}
                <div className="px-4 pt-1 pb-6">
                  <a
                    href="https://discord.gg/unix-team"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-center gap-2 w-full py-3 rounded-xl bg-accent text-brand-dark font-semibold text-[15px] hover:bg-accent/90 transition-colors"
                  >
                    <DiscordIcon size={18} />
                    Join Discord Buat Ribut
                  </a>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Spacer so content doesn't hide behind pill */}
      <div className="h-16" />
    </>
  );
}