#!/usr/bin/env node
/**
 * scripts/migrate-to-json.mjs
 *
 * Migrasikan data dari lib/content.ts & lib/blogPosts.ts ke file JSON.
 * Jalankan sekali: node scripts/migrate-to-json.mjs
 *
 * Setelah selesai:
 * - data/team.json
 * - data/blog.json
 * - data/docs.json
 * - data/projects.json
 * - data/faq.json
 *
 * Update imports di seluruh codebase dari:
 *   import { teamMembers } from '@/lib/content'
 * ke:
 *   import { teamMembers } from '@/lib/data'
 */

import { writeFileSync, mkdirSync, existsSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const ROOT = join(__dirname, '..');
const DATA_DIR = join(ROOT, 'data');

if (!existsSync(DATA_DIR)) mkdirSync(DATA_DIR, { recursive: true });

function save(filename, data) {
  const filePath = join(DATA_DIR, filename);
  writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf-8');
  console.log(`✅  ${filename} (${data.length} items)`);
}

// ── Paste data lama kamu di sini, lalu jalankan script ──────────────────
// Atau import langsung dari file TS pakai tsx/ts-node

// Contoh struktur — ganti dengan data aktual dari lib/content.ts

const teamMembers = [
  {
    id: '1',
    name: 'Mbing SDK',
    role: 'Bukan Ketua',
    tags: ['DEV'],
    bio: 'Orang yang bikin komunitas ini jadi tempat ribut, kacau, dan sangat menyesatkan. Orang yang bikin komunitas ini jadi tempat ribut, kacau, dan sangat menyesatkan. Orang yang bikin komunitas ini jadi tempat ribut, kacau, dan sangat menyesatkan.',
    image: '/images/team/mbing-sdk.png',
    social: {
      roblox: 'https://www.roblox.com/users/8737968881/profile',
      instagram: 'https://instagram.com/mbingsdk',
      tiktok: 'https://www.tiktok.com/@penguinantarctica_',
      discord: 'mbingsdk',
    },
  },
  {
    id: '2',
    name: 'Diks',
    role: 'Ribut Specialist',
    tags: ['CEO-UNIX'],
    bio: 'Ahli dalam bikin kekacauan dan debat hal sepele kayak sidang PBB',
    image: '/images/team/diks.webp',
    social: {
      roblox: 'https://www.roblox.com/users/9114654508/profile',
      instagram: 'https://instagram.com',
      tiktok: 'https://www.tiktok.com',
      discord: 'levioss8313',
    },
  },
  {
    id: '3',
    name: 'Dewut',
    role: 'Bully Expert',
    tags: ['UNIX-INT'],
    bio: 'Anak ganteng, anak bagus, anak sholeh, anak mama, anak papa, anak rajin, anak masjd, anak ganteng, balik lagi. Gajelas paling juga ANAKONDA',
    image: '/images/team/dewut.jpg',
    social: {
      roblox: 'https://www.roblox.com/users/8112187067/profile',
      instagram: 'https://www.instagram.com/_dewokk2',
      tiktok: 'https://www.tiktok.com',
      discord: 'dewutut',
    },
  },
  {
    id: '4',
    name: 'Popol',
    role: 'AFK Legend',
    tags: ['UNIX-INT'],
    bio: 'Anak baik didikan mama papa, semua orang juga tau kalo bintang nya ada di sini, lebih cocok kepiting sih ga bintang deh',
    image: '/images/team/popol.jpg',
    social: {
      roblox: 'https://www.roblox.com/users/7872624261/profile',
      instagram: 'https://www.instagram.com/bodiekats.poll',
      tiktok: 'https://www.tiktok.com/@qpollwin',
      discord: 'katspoll',
    },
  },
  {
    id: '5',
    name: 'Budhe',
    role: 'Yapping Expert',
    tags: ['UNIX-INT'],
    bio: 'Profesional dalam memperpanjang obrolan, karena komunikasi adalah kontribusi. Kalau diem berarti lagi tidur. Yap yap yap no cooldown',
    image: '/images/team/budhe.png',
    social: {
      roblox: 'https://www.roblox.com/users/8268278773/profile',
      instagram: 'https://instagram.com',
      tiktok: 'https://www.tiktok.com',
      discord: 'callmevitaaa',
    },
  },
  {
    id: '6',
    name: 'Abubu is not abubu',
    role: 'Penjaga Pois',
    tags: ['CAPABLE'],
    bio: 'Penjaga pois yg tidak on mic. Diam bukan berarti afk, karena dimana ada drama disitu ada saya',
    image: '/images/team/abubu.webp',
    social: {
      roblox: 'https://www.roblox.com/users/6116826320/profile',
      instagram: 'https://instagram.com',
      tiktok: 'https://www.tiktok.com',
      discord: 'kayfa_12',
    },
  },
  {
    id: '7',
    name: 'Lovell',
    role: 'Juara Disconnect Pois',
    tags: ['CAPABLE'],
    bio: 'kadang suara kayak robot karena jaringan bapuk (seperti suara rakyat yang terbungkam) ',
    image: '/images/team/lovell.png',
    social: {
      roblox: 'https://www.roblox.com/users/9023144736/profile',
      instagram: 'https://instagram.com',
      tiktok: 'https://www.tiktok.com',
      discord: 'lovellme2',
    },
  },
  {
    id: '8',
    name: 'Day',
    role: 'Tukang Kompor',
    tags: ['CEO-UNIX'],
    bio: 'Diem bukan berarti netral tapi sedang mengamati masalah sambil menyiapkan materi supaya masalahnya makin besar',
    image: '/images/team/day.jpg',
    social: {
      roblox: 'https://www.roblox.com/users/9398225319/profile',
      instagram: 'https://instagram.com',
      tiktok: 'https://www.tiktok.com',
      discord: 'inanotherday',
    },
  },
  {
    id: '9',
    name: 'Kotlin',
    role: 'Social Butterfly nya unix',
    tags: ['SKILLED'],
    bio: 'Ahli menjalin relasi di berbagai circle dan "kalkulator" andalan untuk prediksi cuaca ekstrem di Gunung Sumbing',
    image: '/images/team/kotlin.webp',
    social: {
      roblox: 'https://www.roblox.com/users/10190112594/profile',
      instagram: 'https://instagram.com',
      tiktok: 'https://www.tiktok.com',
      discord: 'kottliin',
    },
  },
  {
    id: '10',
    name: 'Maez',
    role: 'Gatau',
    tags: ['CAPABLE'],
    bio: 'Jago summit (tapi ke BC 🗿)',
    image: '/images/team/maez.png',
    social: {
      roblox: 'https://www.roblox.com/users/9464955494/profile',
      instagram: 'https://instagram.com',
      tiktok: 'https://www.tiktok.com',
      discord: 'muzanlur',
    },
  },
  {
    id: '11',
    name: 'Minjekk',
    role: 'Panglima Diskonek',
    tags: ['CAPABLE'],
    bio: 'Klo mau tau lebih jauh bisa langsung call ya cantik <3',
    image: '/images/team/minjekk.jpg',
    social: {
      roblox: 'https://www.roblox.com/users/8917505566/profile',
      instagram: 'https://instagram.com',
      tiktok: 'https://www.tiktok.com/@glbtr',
      discord: 'jal_0569',
    },
  },
  {
    id: '12',
    name: 'Wan',
    role: 'Abang Abangan WASD',
    tags: ['SEASONED'],
    bio: 'Kadang jago kadang anu',
    image: '/images/team/wan.png',
    social: {
      roblox: 'https://www.roblox.com/users/8715337949/profile',
      instagram: 'https://www.instagram.com/irwankurniawann_',
      tiktok: 'https://www.tiktok.com',
      discord: 'wan7799',
    },
  },
  {
    id: '13',
    name: 'Lilaccc',
    role: 'Real Dwonsol',
    tags: ['ADVANCED BEGINNER'],
    bio: 'Cewe stecu , baik hati , lembut , yg paling penting cantip',
    image: '/images/team/lilac.jpg',
    social: {
      roblox: 'https://www.roblox.com/users/8942961359/profile',
      instagram: 'https://www.instagram.com/vanyyy_25',
      tiktok: 'https://www.tiktok.com',
      discord: 'lilacccc.__41251',
    },
  },
];

const blogPosts = [
  {
    id: '1',
    slug: 'panduan-bertahan-di-unix',
    title: 'Panduan Bertahan di UNIX Tanpa Kena Bully (Spoiler: Ga Bisa)',
    description: 'Panduan lengkap buat member baru yang mau survive di UNIX tanpa kehilangan jati diri. Tidak ada jaminan berhasil.',
    date: '2026-04-15',
    category: 'Community',
    author: 'UNIX-TEAM',
    featured: false,
    image: '/images/blog/panduan-bertahan-di-unix.png',
    sections: [
      {
        title: 'Selamat Datang di Kekacauan',
        content: 'Kalau kamu baru join UNIX, selamat. Atau turut berduka. Tergantung perspektif. Di sini ga ada orientasi resmi, ga ada buku panduan, dan ga ada yang bakal nyambut kamu dengan ramah. Tapi entah kenapa, orang-orang betah. Bahkan yang bilang mau quit pun balik lagi dalam seminggu.',
        subsections: [
          {
            title: 'Hal Pertama yang Akan Kamu Rasakan',
            content: 'Bingung. Semua orang ngobrol dengan referensi yang tidak kamu mengerti. Ada nama-nama yang disebut berulang, ada inside joke yang sudah berjalan berbulan-bulan, dan ada dinamika aneh yang tidak punya penjelasan logis. Ini normal. Kamu belum baca Kamus Bahasa UNIX.',
          },
          {
            title: 'Hal Pertama yang Akan Kamu Alami',
            content: 'Dibully. Bukan karena kamu salah sesuatu. Tapi karena kamu baru, dan itu cukup menarik perhatian. Anggap ini sebagai tes. Kalau kamu survive tanpa drama, kamu akan diterima. Kalau kamu bereaksi berlebihan, kamu akan dibully lebih intensif karena itu menghibur.',
          },
        ],
      },
      {
        title: 'Memahami Sistem Komunikasi UNIX',
        content: 'Bahasa yang dipakai di UNIX terlihat seperti Bahasa Indonesia biasa. Tapi setiap kata bisa punya makna berbeda tergantung siapa yang ngomong, jam berapa, dan seberapa gabut mereka.',
        subsections: [
          {
            title: 'Gas',
            content: 'Secara harfiah: siap, ayo jalan. Di UNIX: males banget tapi tidak mau keliatan males, jadi tetap bilang gas sambil tidak melakukan apa-apa.',
          },
          {
            title: 'Ntar',
            content: 'Secara harfiah: nanti, sebentar lagi. Di UNIX: brisik, berhenti nanya, kemungkinan besar tidak akan pernah terjadi. Umur ntar di UNIX bisa berkisar dari 10 menit sampai tidak terbatas.',
          },
          {
            title: 'Diam',
            content: 'Secara harfiah: tidak bersuara. Di UNIX: bisa berarti setuju, tidak setuju, AFK, lagi makan, atau sedang menyiapkan argumen balasan yang lebih panjang dari argumen awalnya.',
          },
        ],
      },
      {
        title: 'Soal Bully: Filosofi dan Praktik',
        content: 'Di UNIX, bully bukan tanda kebencian. Justru sebaliknya. Kalau sudah dibulli berarti kamu sudah dianggap eksis. Yang paling bahaya adalah kalau tidak ada yang ngomong ke kamu sama sekali — itu artinya kamu benar-benar tidak ada di mata komunitas.',
      },
      {
        title: 'Kapan dan Bagaimana Cara Leave',
        content: 'Kalau sudah bosan, boleh leave kapanpun. Ga perlu pamit, ga perlu announcement, ga perlu drama. Silent leave adalah budaya, bukan pengkhianatan. Yang tidak diperbolehkan secara kultural adalah leave dengan fanfare — bilang mau inactive, minta perhatian, atau menunggu orang-orang merayu untuk tetap tinggal. Itu terlalu formal untuk UNIX.',
      },
    ],
  },
  {
    id: '2',
    slug: 'cara-jadi-afk-legend',
    title: 'Cara Jadi AFK Legend yang Paling Ditakuti di UNIX',
    description: 'Panduan menjadi member yang paling sering offline tapi entah kenapa paling direspek. Ini bukan jokes, ini strategi hidup.',
    date: '2026-03-10',
    category: 'Strategi',
    author: 'UNIX-TEAM',
    featured: true,
    image: '/images/blog/cara-jadi-afk-legend.png',
    sections: [
      {
        title: 'Kenapa AFK Legend Bisa Eksis?',
        content: 'Di UNIX, ada paradoks sosial yang unik. Semakin sering kamu online, semakin kamu dianggap biasa. Semakin jarang kamu muncul, semakin aura misteriusmu terbentuk. AFK Legend adalah puncak dari paradoks ini — mereka hampir tidak pernah ada, tapi selalu terasa ada.',
        subsections: [
          {
            title: 'Teori Kelangkaan',
            content: 'Sama seperti barang langka yang harganya mahal, kehadiran yang jarang menciptakan nilai. Member yang online setiap hari jadi background noise. Member yang muncul sekali seminggu jadi event.',
          },
          {
            title: 'Teori Ketidakpastian',
            content: 'Tidak ada yang tahu kapan AFK Legend akan muncul berikutnya. Ketidakpastian ini menciptakan antisipasi. Dan setiap kemunculan terasa seperti kejadian penting, bahkan kalau yang mereka lakukan cuma bilang halo lalu pergi lagi.',
          },
        ],
      },
      {
        title: 'Langkah-Langkah Menjadi AFK Legend',
        content: 'Perlu dicatat: ini bukan sesuatu yang bisa dipaksakan. AFK Legend sejati tidak sedang menjalankan strategi — mereka memang natural seperti ini. Tapi kalau kamu mau mencoba, ini polanya.',
        subsections: [
          {
            title: 'Kurangi Frekuensi Online Secara Gradual',
            content: 'Jangan tiba-tiba menghilang. Kurangi pelan-pelan. Dari online setiap hari menjadi 3 hari sekali, lalu seminggu sekali. Orang-orang akan mulai notice ketiadaanmu sebelum kamu benar-benar pergi.',
          },
          {
            title: 'Pastikan Setiap Kemunculan Berkesan',
            content: 'Saat online, jangan buang waktu untuk hal-hal kecil. Masuk ke percakapan yang sedang panas, beri pendapat yang tidak terduga, lalu pergi. Jangan berlama-lama sampai momen berakhir secara alami.',
          },
          {
            title: 'AFK di Momen yang Paling Dibutuhkan',
            content: 'Ini teknik paling advance. Ketika semua orang menunggumu — saat ada keputusan penting, debat yang menggantung, atau pertanyaan yang hanya kamu bisa jawab — itulah saat yang tepat untuk offline. Biarkan notifikasi menumpuk. Kemunculanmu berikutnya akan terasa seperti kedatangan seseorang yang sangat dinantikan.',
          },
        ],
      },
      {
        title: 'Tanda-Tanda Kamu Sudah Jadi AFK Legend',
        content: 'Nama kamu disebut bahkan saat kamu tidak online. Orang-orang tag kamu di hal-hal yang tidak penting hanya karena ingin tahu kamu masih hidup. Dan setiap kali kamu muncul, ada setidaknya satu orang yang bilang sesuatu seperti "eh kamu masih ada?"',
      },
    ],
  },
  {
    id: '3',
    slug: 'kamus-bahasa-unix',
    title: 'Kamus Bahasa UNIX: Panduan Ngerti Omongan Member',
    description: 'Glossarium resmi (tidak resmi) untuk memahami bahasa komunikasi UNIX yang membingungkan, menyesatkan, dan kadang tidak masuk akal sama sekali.',
    date: '2026-02-05',
    category: 'Community',
    author: 'UNIX-TEAM',
    featured: true,
    image: '/images/blog/kamus-bahasa-unix.png',
    sections: [
      {
        title: 'Pengantar Linguistik UNIX',
        content: 'UNIX memiliki sistem bahasa yang berkembang secara organik tanpa ada yang merancangnya. Tidak ada rapat pembahasan kosakata, tidak ada kesepakatan formal. Kata-kata muncul, dipakai semua orang, dan makna aslinya perlahan bergeser sampai tidak ada yang ingat maksud awalnya.',
      },
      {
        title: 'Kosakata Dasar',
        content: 'Kata-kata yang harus kamu pahami sebelum bisa mengikuti percakapan di UNIX.',
        subsections: [
          {
            title: 'Gas',
            content: 'Arti standar: setuju, ayo mulai. Arti UNIX: aku males tapi tidak mau keliatan males. Tingkat kepastian bahwa sesuatu akan benar-benar terjadi setelah "gas" diucapkan: sekitar 12%.',
          },
          {
            title: 'Ntar',
            content: 'Arti standar: nanti, sebentar lagi. Arti UNIX: brisik, berhenti nanya. Rentang waktu aktual dari "ntar": antara 5 menit dan tidak pernah, dengan distribusi yang sangat condong ke arah tidak pernah.',
          },
          {
            title: 'Gabut',
            content: 'Kondisi default semua member UNIX. Bukan alasan untuk tidak produktif — ini identitas. Orang yang mengaku tidak pernah gabut di UNIX dicurigai adalah bot atau salah masuk server.',
          },
          {
            title: 'Nyawit',
            content: 'Kondisi psikologis di mana seseorang terus menunggu sesuatu yang jelas tidak akan datang, tapi tetap menunggu dengan tenang dan penuh keyakinan. Berbeda dari hopium karena nyawit lebih pasif — tidak aktif berharap, hanya diam menunggu takdir.',
          },
        ],
      },
      {
        title: 'Istilah Tingkat Lanjut',
        content: 'Kosakata yang baru bisa dipahami setelah minimal dua minggu bergabung dan mengalaminya sendiri.',
        subsections: [
          {
            title: 'Copium, Hopium, dan Delusionium',
            content: 'Tiga sumber energi utama UNIX. Copium adalah harapan yang tahu dirinya sia-sia tapi dipelihara juga. Hopium adalah keyakinan bahwa hal mustahil tetap mungkin kalau mau sabar. Delusionium adalah ketika seseorang mengkombinasikan keduanya dan menambahkan lapisan kepercayaan diri yang sama sekali tidak berdasar. Ketiganya dianggap normal di sini.',
          },
          {
            title: 'Sidang PBB',
            content: 'Istilah untuk menggambarkan cara member UNIX mendebat topik yang sama sekali tidak penting dengan intensitas dan keseriusan seperti negosiasi perdamaian internasional. Topik yang pernah jadi sidang PBB antara lain: apakah mie instan lebih enak dimasak atau diseduh, dan siapa yang paling benar soal build karakter yang jelas-jelas semua salah.',
          },
          {
            title: 'Silent Leave',
            content: 'Tindakan meninggalkan server atau percakapan tanpa pemberitahuan apapun. Di komunitas lain ini mungkin dianggap kasar. Di UNIX ini adalah norma yang dihormati. Bahkan ada yang bilang silent leave adalah satu-satunya cara keluar yang bermartabat.',
          },
        ],
      },
    ],
  },
  {
    id: '4',
    slug: 'sejarah-rivalri-katspoll',
    title: 'Sejarah Legendaris Rivalri UNIX vs @katspoll',
    description: 'Dokumentasi tidak resmi tentang perjalanan panjang bully-membully yang membentuk identitas UNIX dan melahirkan seorang NPC legendaris.',
    date: '2026-01-28',
    category: 'Lore',
    author: 'UNIX-TEAM',
    featured: false,
    image: '/images/blog/sejarah-rivalri-katspoll.png',
    sections: [
      {
        title: 'Catatan Sejarawan',
        content: 'Artikel ini ditulis berdasarkan kesaksian kolektif member UNIX yang ingatannya tidak selalu akurat karena sebagian besar kejadian berlangsung di sela-sela sesi gaming dan debat tidak penting. Beberapa detail mungkin dilebih-lebihkan secara tidak sengaja. Tapi spiritnya akurat.',
      },
      {
        title: 'Asal Usul yang Tidak Jelas',
        content: 'Tidak ada yang bisa menunjuk satu momen spesifik sebagai awal dari tradisi ini. Yang pasti, @katspoll sudah ada sejak awal komunitas terbentuk, dan tradisi bullynya tumbuh secara organik tanpa ada yang merancang.',
        subsections: [
          {
            title: 'Hipotesis Pertama',
            content: 'Ada yang berpendapat tradisi ini dimulai karena @katspoll pernah mengeluarkan pendapat yang kontroversial di awal-awal komunitas berdiri. Tidak ada yang ingat pendapatnya apa, tapi konsekuensinya bertahan sampai sekarang.',
          },
          {
            title: 'Hipotesis Kedua',
            content: 'Ada yang percaya tidak ada pemicu spesifik. @katspoll hanya ada di tempat yang tepat pada waktu yang salah, dan momentum terbentuk sendiri. Ini mungkin penjelasan yang paling masuk akal.',
          },
        ],
      },
      {
        title: 'Evolusi Status: Dari Korban ke Legenda',
        content: 'Yang menarik dari kisah @katspoll bukan bullying-nya — itu hal biasa. Yang menarik adalah bagaimana dia berevolusi dari target menjadi karakter sentral komunitas.',
        subsections: [
          {
            title: 'Fase 1: Korban Biasa',
            content: 'Tahap awal. Dibulli karena baru dan ada. Reaksinya tidak berlebihan, tidak drama, dan itu membuatnya menjadi target yang aman sekaligus membosankan untuk ditinggalkan. Bertahan di fase ini lebih lama dari rata-rata orang.',
          },
          {
            title: 'Fase 2: Target Favorit',
            content: 'Setelah cukup lama survive, @katspoll mulai punya "fanbase bully" sendiri. Member baru yang join secara otomatis diperkenalkan ke tradisi ini sebagai bagian dari onboarding tidak resmi.',
          },
          {
            title: 'Fase 3: NPC Legendaris',
            content: 'Status tertinggi yang bisa dicapai seseorang di UNIX tanpa menjadi Popol. NPC Legendaris adalah karakter yang sudah menjadi bagian dari DNA komunitas. Kehadirannya memberi struktur pada kekacauan yang ada.',
          },
        ],
      },
      {
        title: 'Status Terkini dan Proyeksi Masa Depan',
        content: 'Tradisi masih berlanjut, @katspoll masih ada, dan tidak ada tanda-tanda perubahan dalam waktu dekat. Ini mungkin adalah hubungan paling konsisten yang pernah ada di UNIX — di antara semua hal yang tidak pernah selesai dan tidak pernah jelas, setidaknya ini stabil.',
      },
    ],
  },
  {
    id: '5',
    slug: 'mabar-pembubaran-unix',
    title: 'Mabar Pembubaran UNIX: Foto Bareng 6 Jam, Satu Baris Pun Belum Lurus',
    description: 'Dokumentasi resmi sesi mabar terakhir UNIX yang harusnya penuh haru tapi berakhir jadi rekaman terlengkap tentang bagaimana jaringan bisa menghancurkan segalanya.',
    date: '2026-05-09',
    category: 'Chaos',
    author: 'UNIX-TEAM',
    featured: true,
    image: '/images/blog/mabar-pembubaran-unix.jpg',
    sections: [
      {
        title: 'Latar Belakang yang Tidak Perlu Tapi Tetap Ada',
        content: 'Mabar Pembubaran UNIX dijadwalkan mulai jam 8 malam. Konsepnya sederhana: main bareng satu sesi terakhir, foto bareng, selesai. Tidak ada yang menduga bahwa kata "sederhana" di kalimat sebelumnya adalah kesalahan fatal terbesar dalam sejarah komunitas ini.',
      },
      {
        title: 'Babak Pertama: Kena Petir Sebelum Main',
        content: 'Jam 7:58, dua menit sebelum jadwal, sambaran petir menghantam tiang listrik di dekat rumah salah satu member. Router-nya mati. Bukan metafora, bukan dramatis, benar-benar mati. Ada asap. Member tersebut masih sempat kirim pesan "bro router aku" sebelum hilang dari voice untuk 20 menit berikutnya.',
        subsections: [
          {
            title: 'Korban Jaringan Berikutnya',
            content: 'Empat menit setelah insiden petir, dua member lain disconnect tanpa sebab yang jelas. Tidak ada petir di lokasi mereka. Tidak ada gangguan listrik. Sinyalnya hanya memutus sendiri karena memang begitulah sifatnya — tidak butuh alasan, tidak butuh momen dramatis, cukup pergi begitu saja seperti mantan yang ga ada chemistry-nya.',
          },
          {
            title: 'Proses Reconnect yang Berlangsung 47 Menit',
            content: 'Total waktu yang dihabiskan untuk menunggu semua orang bisa join sebelum main dimulai adalah 47 menit. Proses ini melibatkan dua restart modem, satu kejadian cabut-colok kabel yang tidak perlu diceritakan lebih lanjut, dan tiga kali ganti server karena yang pertama lagnya tidak manusiawi, yang kedua lebih buruk, dan yang ketiga entah kenapa sudah tidak bisa diakses padahal baru dipakai kemarin.',
          },
        ],
      },
      {
        title: 'Babak Kedua: Sesi Foto Bareng Dimulai',
        content: 'Setelah main beberapa ronde yang hasilnya tidak perlu didokumentasikan, tibalah sesi yang paling ditunggu: foto bareng. Rencananya cepat. Baris, screenshot, selesai. Kenyataannya berbeda secara signifikan.',
        subsections: [
          {
            title: 'Percobaan Pertama sampai Kesepuluh',
            content: 'Dari sepuluh percobaan pertama, tidak satu pun menghasilkan foto yang bisa dipakai. Alasannya bervariasi: ada yang masih loading, ada yang karakternya jongkok sendiri tanpa input, ada yang disconnect tepat saat semua orang sudah siap, dan ada yang entah bagaimana berhasil berdiri di tengah-tengah orang lain padahal seharusnya tidak mungkin secara spasial.',
          },
          {
            title: 'Percobaan Kesebelas sampai Ketiga Puluh Satu',
            content: 'Polanya tidak membaik. Dari 31 total percobaan yang tercatat, 14 gagal karena ada yang tertinggal di spawn, 7 karena salah arah hadap kamera, 5 karena ada yang posisinya tidak pernah bisa lurus dengan siapapun di sekitarnya meski sudah diulang berkali-kali, 3 karena ada yang tiba-tiba emote tanpa koordinasi, 2 karena lag menggeser kamera di momen paling penting, dan 1 karena salah satu karakter terbang ke atas secara vertikal tanpa pernah kembali. Member yang karakternya terbang tersebut tidak bisa menjelaskan kenapa. Kami juga tidak bisa.',
          },
        ],
      },
      {
        title: 'Babak Ketiga: Jaringan sebagai Antagonis Utama',
        content: 'Di antara semua kekacauan yang terjadi, satu hal yang konsisten adalah disconnect. Setiap kali ada yang bilang "oke semua siap?", dalam radius tiga detik seseorang pasti terputus. Ini terjadi cukup sering sampai kalimat tersebut mulai dihindari secara kolektif. Kita coba ganti kata-katanya. Tidak membantu. Kita coba diam dan langsung screenshot. Tetap ada yang disconnect. Pada titik ini ada yang menyarankan bahwa mungkin masalahnya bukan jaringan, tapi kalimat itu sendiri yang dikutuk. Tidak ada yang menyanggah teori ini.',
        subsections: [
          {
            title: 'Pindah Server Sebanyak Tiga Kali',
            content: 'Dalam upaya mengatasi masalah koneksi, kita pindah server. Hasilnya sama. Pindah lagi, lebih buruk. Pindah ke server ketiga, kondisinya tidak lebih baik dari server pertama. Mencoba kembali ke server pertama, server tersebut sudah tidak bisa diakses. Tidak ada notifikasi, tidak ada penjelasan, hanya tidak bisa dibuka.',
          },
          {
            title: 'Member yang Disconnect Paling Banyak',
            content: 'Orang yang terkena petir di awal acara tercatat disconnect sebanyak tujuh kali dalam satu sesi. Ini menjadi rekor tidak resmi yang mungkin tidak akan ada yang sengaja berusaha melampaui. Setiap kali dia berhasil masuk, ada jeda sekitar dua menit sebelum dia terputus lagi. Pola ini sangat konsisten sampai beberapa orang mulai menghitung dan bertaruh kapan disconnect berikutnya terjadi.',
          },
        ],
      },
      {
        title: 'Akhir yang Tidak Dramatis Sama Sekali',
        content: 'Jam 3 pagi, setelah kurang lebih enam jam, foto bareng resmi dinyatakan belum selesai dan ditunda tanpa tanggal yang jelas. Bukan karena menyerah, tapi karena ada yang harus bangun jam 6. Yang tersisa dari seluruh sesi ini adalah 47 screenshot gagal, beberapa rekaman layar yang blur di bagian paling penting, dan satu foto di mana hanya dua dari dua belas orang yang seharusnya ada bisa terlihat. Sisanya tidak ada di frame, tidak ada penjelasan kenapa, dan tidak ada yang cukup peduli untuk menyelidikinya lebih lanjut. Foto finalnya belum ada sampai artikel ini ditulis. Kemungkinan besar tidak akan pernah ada.',
      },
    ],
  },
];

const docPages = [
  {
    id: '1',
    slug: 'cara-join',
    title: 'Cara Join UNIX (Dan Kenapa Kamu Mungkin Akan Menyesal)',
    description: 'Panduan resmi tidak resmi untuk bergabung ke komunitas yang tidak sehat tapi entah kenapa hangat ini.',
    category: 'Memulai',
    order: 1,
    sections: [
      {
        title: 'Syarat untuk Join',
        content: 'Tidak ada. Ini bukan typo. Benar-benar tidak ada syarat. Tidak perlu umur minimal, tidak perlu pengalaman gaming, tidak perlu keahlian khusus, tidak perlu nulis motivation letter. Cukup punya Discord dan mau ribut.',
        tips: 'Kalau kamu mencari komunitas dengan seleksi ketat dan hierarki formal, kamu salah tempat. Kalau kamu mencari tempat gabut yang entah kenapa produktif, lanjutkan membaca.',
      },
      {
        title: 'Proses Join',
        content: 'Klik link Discord. Itu saja. Serius.',
        subsections: [
          {
            title: 'Langkah 1',
            content: 'Klik link Discord yang tersedia di halaman utama website ini.',
          },
          {
            title: 'Langkah 2',
            content: 'Kamu sudah masuk. Selamat atau turut berduka, tergantung perspektif.',
          },
          {
            title: 'Langkah 3 (Opsional)',
            content: 'Baca rules. Tapi kalau tidak mau baca pun tidak ada konsekuensinya, karena isi rules pada dasarnya hanya "kamu bebas melakukan apapun".',
          },
        ],
      },
      {
        title: 'Apa yang Terjadi Setelah Join',
        content: 'Beberapa skenario yang mungkin terjadi, berurutan dari paling umum ke paling jarang.',
        subsections: [
          {
            title: 'Skenario A: Tidak Ada yang Notice',
            content: 'Paling umum. Kamu masuk, channel penuh percakapan yang tidak kamu mengerti, dan tidak ada yang menyapa. Ini bukan tanda penolakan. Semua orang sibuk ribut. Beri waktu.',
          },
          {
            title: 'Skenario B: Langsung Dibully',
            content: 'Ini justru tanda bagus. Berarti ada yang notice kehadiranmu dan menganggapmu cukup menarik untuk diganggu. Respon dengan santai dan kamu akan baik-baik saja.',
          },
          {
            title: 'Skenario C: Disambut dengan Hangat',
            content: 'Sangat jarang terjadi tapi pernah ada presedennya. Kalau ini terjadi, jangan terlalu terharu — besoknya kamu tetap akan dibully.',
          },
        ],
        tips: 'Perkenalan tidak wajib. Tapi kalau mau perkenalan, hindari terlalu formal. "Halo, nama saya X, saya tertarik bergabung karena..." akan langsung mendapat reaksi yang tidak ingin kamu terima.',
      },
      {
        title: 'Cara Keluar Kalau Sudah Bosan',
        content: 'Leave saja. Tanpa pamit, tanpa pengumuman, tanpa drama. Silent leave adalah budaya yang dihormati di UNIX. Kalau mau balik lagi, juga tidak perlu announcement — masuk saja seolah tidak pernah pergi. Tidak ada yang akan nanya kemana saja.',
      },
    ],
  },
  {
    id: '2',
    slug: 'hierarki-unix',
    title: 'Hierarki Tidak Resmi UNIX yang Tidak Diakui tapi Semua Tahu',
    description: 'Peta tatanan sosial absurd di UNIX yang tidak pernah ditulis tapi berjalan dengan konsistensi yang mengkhawatirkan.',
    category: 'Memulai',
    order: 2,
    sections: [
      {
        title: 'Disclaimer Penting',
        content: 'UNIX secara resmi tidak memiliki hierarki. Tidak ada struktur jabatan, tidak ada ketua, tidak ada moderator dengan kekuasaan nyata. Dokumen ini tidak resmi dan tidak diakui oleh siapapun. Tapi kalau kamu sudah cukup lama di sini, kamu tahu ini akurat.',
      },
      {
        title: 'Tingkatan yang Ada',
        content: 'Ada beberapa level tidak resmi yang diakui secara kolektif tanpa pernah dibahas secara eksplisit.',
        subsections: [
          {
            title: 'Member Baru',
            content: 'Fase awal semua orang. Ditandai dengan tidak mengerti konteks apapun, sering salah baca situasi, dan jadi target bully yang dimaafkan karena "belum tahu". Fase ini berlangsung antara seminggu sampai sebulan, tergantung seberapa cepat kamu menyerap budaya lokal.',
          },
          {
            title: 'Member Biasa',
            content: 'Sudah paham konteks, sudah punya inside joke sendiri, sudah tahu siapa yang jangan diganggu dan siapa yang aman untuk dibulli. Mayoritas populasi UNIX ada di sini. Tidak ada ambisi untuk naik level, dan itu sepenuhnya valid.',
          },
          {
            title: 'Yang Paling Ribut',
            content: 'Level informal yang dicapai melalui konsistensi ribut yang tinggi dan pendapat-pendapat yang selalu memancing diskusi. Dianggap paling bijak bukan karena paling benar, tapi karena paling banyak ngomong dan masih didengarkan.',
          },
          {
            title: 'AFK Legend',
            content: 'Paradoks tertinggi dalam hierarki UNIX. Paling jarang online, tapi paling ditakuti. Ketika mereka muncul, semua notice. Ketika mereka ngomong, semua dengerin. Ketika mereka pergi lagi, semua masih membahas apa yang mereka bilang tadi.',
          },
        ],
      },
      {
        title: 'Posisi Khusus yang Tidak Masuk Hierarki Normal',
        content: 'Beberapa entitas di UNIX memiliki posisi yang tidak bisa dikategorikan dalam hierarki standar.',
        subsections: [
          {
            title: 'Popol',
            content: 'Satu-satunya entitas yang boleh dipuji di UNIX tanpa mendapat reaksi negatif. Posisinya ada di atas semua hierarki normal dan tidak bisa diganggu gugat. Tidak ada yang tahu persis bagaimana Popol bisa mencapai status ini. Ada yang bilang sudah masuk tahap disembah. Tidak ada yang membantah.',
          },
          {
            title: 'CEO Diks',
            content: 'Jabatan yang terdengar bergengsi tapi secara operasional adalah posisi paling tragis di UNIX. Tugasnya berdagang. Misinya — yang didukung penuh oleh komunitas — adalah terus rugi demi menjaga keseimbangan kosmis ekonomi UNIX. Tidak ada yang benar-benar mengerti kenapa ini harus terjadi, tapi semua sepakat bahwa itu perlu.',
          },
          {
            title: '@katspoll: NPC Legendaris',
            content: 'Bukan member biasa, bukan AFK Legend. @katspoll telah bertransendensi dari kategori member dan menjadi karakter — bagian dari cerita yang tidak bisa dihapus tanpa mengubah identitas komunitas itu sendiri.',
          },
        ],
        tips: 'Jangan mencoba merebut posisi-posisi khusus ini. Mereka tidak bisa direbut. Mereka terbentuk secara organik dan waktu yang memutuskan siapa yang mendapatkannya.',
      },
    ],
  },
  {
    id: '3',
    slug: 'budaya-unix',
    title: 'Budaya dan Tradisi UNIX yang Wajib Tapi Tidak Pernah Diajarkan',
    description: 'Kompilasi norma, kebiasaan, dan tradisi tidak tertulis yang membentuk identitas UNIX sebagai komunitas yang aneh tapi entah kenapa berfungsi.',
    category: 'Komunitas',
    order: 3,
    sections: [
      {
        title: 'Mengapa Budaya Ini Tidak Tertulis',
        content: 'Karena tidak ada yang sempat menulisnya. Komunitas ini tumbuh terlalu organik dan terlalu cepat untuk didokumentasikan dengan benar. Dokumen ini adalah upaya pertama, dan sudah terlambat beberapa bulan dari seharusnya.',
      },
      {
        title: 'Tradisi Inti',
        content: 'Beberapa praktik yang sudah menjadi bagian tak terpisahkan dari kehidupan UNIX.',
        subsections: [
          {
            title: 'Silent Leave',
            content: 'Pergi tanpa pamit. Ini bukan ketidaksopanan — ini efisiensi komunikasi. Tidak ada yang perlu tahu kamu pergi. Kalau kamu kembali, tidak ada yang perlu tahu kamu sudah kembali. Kamu hanya ada atau tidak ada, dan itu cukup.',
          },
          {
            title: 'Ritual Bully @katspoll',
            content: 'Bukan bullying dalam arti negatif — ini lebih ke olahraga komunal. Setiap member, cepat atau lambat, akan ikut berpartisipasi. @katspoll tidak keberatan, atau setidaknya sudah melewati fase keberatan.',
          },
          {
            title: 'Debat Sidang PBB',
            content: 'Topik apapun bisa berubah menjadi debat serius kalau timing-nya tepat. Pilihan topping pizza, meta game yang sudah tidak relevan, atau pendapat tentang karakter fiksi bisa berlangsung berjam-jam dengan argumen yang lebih terstruktur dari diskusi kebanyakan orang tentang hal-hal yang sebenarnya penting.',
          },
        ],
      },
      {
        title: 'Filosofi Tidak Resmi UNIX',
        content: 'Ada beberapa prinsip yang dipegang secara kolektif, walaupun tidak ada yang pernah menyebutkannya sebagai prinsip.',
        subsections: [
          {
            title: 'Alon-Alon Masak Kalkun',
            content: 'Pendekatan UNIX terhadap segala hal yang membutuhkan usaha. Tidak perlu terburu-buru. Kerjakan dengan santai, sambil ngobrol, sambil ribut kalau perlu. Hasilnya mungkin datang lebih lambat dari yang seharusnya. Tapi lebih baik selesai dengan tenang daripada selesai dengan burnout.',
          },
          {
            title: 'Copium sebagai Bahan Bakar',
            content: 'UNIX berjalan di atas copium kolektif. Harapan yang secara logis tidak mungkin terwujud tapi tetap dipelihara bersama. Ada yang bilang ini tidak sehat. Tapi tanpa copium, separuh project UNIX tidak akan pernah dimulai — dan meskipun tidak selesai, setidaknya sudah dimulai.',
          },
          {
            title: 'Solidaritas yang Kelihatannya Palsu',
            content: 'Semua orang bilang gas tapi tidak ada yang bergerak. Semua orang bilang ntar tapi tidak ada yang tahu kapan. Tapi ketika ada yang benar-benar butuh sesuatu — ketika situasinya nyata dan mendesak — entah dari mana, orang-orang muncul. Solidaritasnya terlihat palsu di permukaan, tapi strukturnya ada di bawah.',
          },
        ],
        tips: 'Tidak perlu mencoba memahami semua ini sekaligus. Sebagian besar hal di UNIX baru masuk akal setelah kamu mengalaminya, bukan setelah kamu membacanya.',
      },
    ],
  },
];

const projects = [
  {
    id: '1',
    slug: 'sumbing-weather-companion',
    title: 'SumbingWeatherCompanion',
    description:
      '(Desktop) Aplikasi cuaca khusus Gunung Sumbing. Dibuat karena ada member yang naik gunung tanpa cek cuaca dan nyaris tidak kembali. Kini jadi peringatan hidup tentang pentingnya persiapan.',
    category: 'Tool',
    status: 'Active',
    tags: ['Python', 'Utility', 'Desktop', 'Open Source'],
    featured: true,
    image: '/images/projects/sumbing-weather-companion.png',
    demoUrl: 'https://github.com/mbingsdk/MountSumbingCompanion/releases',
  },
  {
    id: '2',
    slug: 'sumbing-companion-apk',
    title: 'SumbingCompanionAPK',
    description:
      '(Mobile) Port dari SumbingWeatherCompanion ke Android, karena laptopnya ketinggalan. Fungsionalitasnya sama, ukurannya lebih kecil, dan kemungkinan crash-nya lebih besar. Tetap lebih baik dari tidak ada sama sekali.',
    category: 'Tool',
    status: 'Active',
    tags: ['Kotlin', 'Utility', 'Mobile', 'Open Source'],
    featured: true,
    image: '/images/projects/sumbing-companion-apk.jpg',
    demoUrl:
      'http://github.com/mbingsdk/MountSumbingCompanion/releases/tag/v0.3.15.BETA',
  },
  {
    id: '3',
    slug: 'roblox-npc-automation',
    title: 'RobloxNPCAutomationLUA',
    description:
      '(Library) Bikin NPC yang bisa jalan sendiri, ambil keputusan sendiri, dan mungkin lebih cerdas dari beberapa pemain di server. Dikembangkan setelah sesi panjang mengamati NPC bawaan Roblox yang keputusannya mengecewakan.',
    category: 'Library',
    status: 'Active',
    tags: ['RobloxLua', 'AI', 'Library'],
    featured: true,
    image: '/images/projects/roblox-npc-automation.png',
    demoUrl: 'https://github.com/unix-team/roblox-npc-automation',
  },
  {
    id: '4',
    slug: 'admin-client-hub',
    title: 'AdminClientHub',
    description:
      '(Library) Toolkit admin yang fitur utamanya adalah kemampuan memantau situasi server dari jauh. Fitur kick ada, tapi menurut dokumentasinya sendiri "harap digunakan dengan bijaksana", yang di UNIX artinya tidak pernah bijaksana.',
    category: 'Library',
    status: 'Active',
    tags: ['RobloxLua', 'Admin', 'Library'],
    featured: false,
    image: '/images/projects/admin-client-hub.jpg',
    demoUrl: 'https://github.com/unix-team/admin-client-hub',
  },
  {
    id: '5',
    slug: 'script-generator',
    title: 'ScriptGenerator',
    description:
      '(Tool) AI yang harusnya bisa generate script otomatis. Masih dalam pengembangan karena setiap kali hampir selesai, ada yang punya ide "fitur tambahan" yang menggeser deadline tanpa batas. Progress: ada. ETA: copium.',
    category: 'Tool',
    status: 'In Development',
    tags: ['AI', 'CodeGen', 'Tool'],
    featured: false,
    image: '/images/projects/script-generator.jpg',
    demoUrl: 'https://github.com/unix-team/script-generator',
  },
  {
    id: '6',
    slug: 'debug-console',
    title: 'DebugConsole',
    description:
      '(Tool) Console debug yang output error messagenya lebih deskriptif dari bawaan. Lahir dari frustasi membaca pesan error yang isinya cuma angka dan nama file yang tidak ada di project manapun yang pernah ada.',
    category: 'Tool',
    status: 'Active',
    tags: ['Debug', 'Development', 'Tool'],
    featured: false,
    image: '/images/projects/debug-console.jpg',
    demoUrl: 'https://github.com/unix-team/debug-console',
  },
];

const faqItems = [
  // Gabung & Komunitas
  {
    id: 'faq-1',
    question: 'Gimana cara gabung UNIX-TEAM?',
    answer:
      'Gampang banget. Klik tombol Join Discord yang ada di mana-mana di website ini, lalu join server kita. Ga ada seleksi ketat, ga ada tes masuk. Yang penting lu bisa toleransi kekacauan.',
    category: 'Gabung & Komunitas',
  },
  {
    id: 'faq-2',
    question: 'Siapa aja yang boleh gabung?',
    answer:
      'Semua orang boleh. Ga peduli lu gamer, coder, desainer, atau cuma penonton. Selama lu bisa jaga attitude dan ga nyebar toxic yang kebangetan, lu welcome di sini.',
    category: 'Gabung & Komunitas',
  },
  {
    id: 'faq-3',
    question: 'Ada biaya buat jadi member UNIX-TEAM?',
    answer:
      'Gratis. Selamanya gratis. Kita ga minta duit buat gabung. Kalau ada yang minta bayar atas nama UNIX-TEAM, itu bukan kita — itu scammer, laporin ke admin.',
    category: 'Gabung & Komunitas',
  },
  {
    id: 'faq-4',
    question: 'UNIX-TEAM komunitas apa sebenernya?',
    answer:
      'Komunitas gaming dan teknologi yang fokus ke Roblox dan hal-hal sekitarnya. Tapi pada prakteknya, kita lebih sering ngobrol hal random, debat ga penting, dan saling bully dengan penuh kasih sayang.',
    category: 'Gabung & Komunitas',
  },

  // Discord & Server
  {
    id: 'faq-5',
    question: 'Aturan di server Discord ada apa aja?',
    answer:
      'Simpel: jangan spam berlebihan, jangan NSFW, jangan rasis/diskriminasi, dan jangan doxxing siapapun. Sisanya cukup pakai akal sehat. Admin bakal kick kalau lu udah kebangetan.',
    category: 'Discord & Server',
  },
  {
    id: 'faq-6',
    question: 'Gimana cara dapat role di Discord?',
    answer:
      'Ada beberapa role yang bisa didapat otomatis berdasarkan aktivitas, dan ada yang dikasih manual sama admin. Rajin aktif di channel, bantu orang lain, dan jangan ghosting — ntar keliatan sendiri.',
    category: 'Discord & Server',
  },
  {
    id: 'faq-7',
    question: 'Server Discord sering down ga?',
    answer:
      'Kalau Discord-nya yang down, itu urusan Discord, bukan kita. Kalau server kita yang sepi, itu bukan down — itu semua lagi AFK bareng. Cek halaman Server Status buat lihat kondisi layanan kita.',
    category: 'Discord & Server',
  },
  {
    id: 'faq-8',
    question: 'Boleh promote server atau komunitas lain?',
    answer:
      'Ga boleh sembarangan. Kalau mau collab atau promote sesuatu, hubungi admin dulu. Kalau langsung spam invite link di channel, langsung ban tanpa peringatan.',
    category: 'Discord & Server',
  },

  // Kegiatan & Event
  {
    id: 'faq-9',
    question: 'Ada event atau kegiatan rutin di UNIX-TEAM?',
    answer:
      'Ada, tapi jadwalnya sering menyesuaikan mood anggota. Biasanya ada game bareng, giveaway random, dan kadang-kadang kompetisi kecil-kecilan. Pantau channel #announcements biar ga ketinggalan.',
    category: 'Kegiatan & Event',
  },
  {
    id: 'faq-10',
    question: 'Bisa usul kegiatan atau event baru ga?',
    answer:
      'Bisa banget. Sampaikan idemu di channel yang relevan atau langsung DM admin. Kalau idenya bagus dan realistis buat dilaksanain, kita pertimbangin. Kalau aneh tapi seru, mungkin juga kita jalanin.',
    category: 'Kegiatan & Event',
  },
  {
    id: 'faq-11',
    question: 'Gimana cara ikut proyek yang lagi jalan?',
    answer:
      'Cek channel #projects di Discord untuk info proyek yang lagi aktif. Kalau tertarik, langsung mention atau DM yang pegang proyeknya. Kita terbuka buat kolaborasi selama lu serius dan ga ghosting di tengah jalan.',
    category: 'Kegiatan & Event',
  },

  // Lain-lain
  {
    id: 'faq-12',
    question: 'Kalau ada masalah di komunitas, lapor ke siapa?',
    answer:
      'Langsung DM salah satu admin atau moderator yang aktif. Atau bisa juga pakai channel #support kalau ga mau DM. Kita usahain respons cepat, kecuali semua lagi tidur atau AFK.',
    category: 'Lain-lain',
  },
  {
    id: 'faq-13',
    question: 'UNIX-TEAM punya media sosial lain selain Discord?',
    answer:
      'Ada Twitter/X dan GitHub. Linknya ada di footer website ini. Tapi pusat aktivitas utama kita tetap di Discord — media sosial lain lebih ke pengumuman atau update sesekali.',
    category: 'Lain-lain',
  },
  {
    id: 'faq-14',
    question: 'Bisa leave server kapan aja?',
    answer:
      'Tentu. Ga ada yang bakal nahan. Silent leave is our culture — ga perlu drama, ga perlu pamit panjang-panjang. Tapi kalau balik lagi, pintunya selalu terbuka.',
    category: 'Lain-lain',
  },
];

save('team.json', teamMembers);
save('blog.json', blogPosts);
save('docs.json', docPages);
save('projects.json', projects);
save('faq.json', faqItems);

console.log('\nDone! Update imports di codebase kamu:');
console.log("  import { teamMembers } from '@/lib/data'");
console.log("  import { blogPosts }   from '@/lib/data'");
console.log("  import { docPages }    from '@/lib/data'");
console.log("  import { projects }    from '@/lib/data'");
console.log("  import { faqItems }    from '@/lib/data'");
