// import { calcReadingTime } from '@/lib/utils';

export interface BlogPost {
  id: string;
  slug: string;
  title: string;
  description: string;
  date: string;
  readingTime: string;
  category: string;
  author?: string;
  featured: boolean;
  image?: string;
  content?: string;
  sections?: Array<{
    title: string;
    content: string;
    code?: string;
    subsections?: Array<{
      title: string;
      content: string;
    }>;
  }>;
}

// // Helper biar post baru ga perlu isi readingTime manual
// function post(p: Omit<BlogPost, 'readingTime'> & { readingTime?: string }): BlogPost {
//   return {
//     ...p,
//     readingTime: p.readingTime ?? calcReadingTime(p.sections),
//   };
// }

// export const blogPosts: BlogPost[] = [
//   post({
//     id: '1',
//     slug: 'panduan-bertahan-di-unix',
//     title: 'Panduan Bertahan di UNIX Tanpa Kena Bully (Spoiler: Ga Bisa)',
//     description: 'Panduan lengkap buat member baru yang mau survive di UNIX tanpa kehilangan jati diri. Tidak ada jaminan berhasil.',
//     date: '2026-04-15',
//     category: 'Community',
//     author: 'UNIX-TEAM',
//     featured: false,
//     image: '/images/blog/panduan-bertahan-di-unix.png',
//     sections: [
//       {
//         title: 'Selamat Datang di Kekacauan',
//         content: 'Kalau kamu baru join UNIX, selamat. Atau turut berduka. Tergantung perspektif. Di sini ga ada orientasi resmi, ga ada buku panduan, dan ga ada yang bakal nyambut kamu dengan ramah. Tapi entah kenapa, orang-orang betah. Bahkan yang bilang mau quit pun balik lagi dalam seminggu.',
//         subsections: [
//           {
//             title: 'Hal Pertama yang Akan Kamu Rasakan',
//             content: 'Bingung. Semua orang ngobrol dengan referensi yang tidak kamu mengerti. Ada nama-nama yang disebut berulang, ada inside joke yang sudah berjalan berbulan-bulan, dan ada dinamika aneh yang tidak punya penjelasan logis. Ini normal. Kamu belum baca Kamus Bahasa UNIX.',
//           },
//           {
//             title: 'Hal Pertama yang Akan Kamu Alami',
//             content: 'Dibully. Bukan karena kamu salah sesuatu. Tapi karena kamu baru, dan itu cukup menarik perhatian. Anggap ini sebagai tes. Kalau kamu survive tanpa drama, kamu akan diterima. Kalau kamu bereaksi berlebihan, kamu akan dibully lebih intensif karena itu menghibur.',
//           },
//         ],
//       },
//       {
//         title: 'Memahami Sistem Komunikasi UNIX',
//         content: 'Bahasa yang dipakai di UNIX terlihat seperti Bahasa Indonesia biasa. Tapi setiap kata bisa punya makna berbeda tergantung siapa yang ngomong, jam berapa, dan seberapa gabut mereka.',
//         subsections: [
//           {
//             title: 'Gas',
//             content: 'Secara harfiah: siap, ayo jalan. Di UNIX: males banget tapi tidak mau keliatan males, jadi tetap bilang gas sambil tidak melakukan apa-apa.',
//           },
//           {
//             title: 'Ntar',
//             content: 'Secara harfiah: nanti, sebentar lagi. Di UNIX: brisik, berhenti nanya, kemungkinan besar tidak akan pernah terjadi. Umur ntar di UNIX bisa berkisar dari 10 menit sampai tidak terbatas.',
//           },
//           {
//             title: 'Diam',
//             content: 'Secara harfiah: tidak bersuara. Di UNIX: bisa berarti setuju, tidak setuju, AFK, lagi makan, atau sedang menyiapkan argumen balasan yang lebih panjang dari argumen awalnya.',
//           },
//         ],
//       },
//       {
//         title: 'Soal Bully: Filosofi dan Praktik',
//         content: 'Di UNIX, bully bukan tanda kebencian. Justru sebaliknya. Kalau sudah dibulli berarti kamu sudah dianggap eksis. Yang paling bahaya adalah kalau tidak ada yang ngomong ke kamu sama sekali — itu artinya kamu benar-benar tidak ada di mata komunitas.',
//       },
//       {
//         title: 'Kapan dan Bagaimana Cara Leave',
//         content: 'Kalau sudah bosan, boleh leave kapanpun. Ga perlu pamit, ga perlu announcement, ga perlu drama. Silent leave adalah budaya, bukan pengkhianatan. Yang tidak diperbolehkan secara kultural adalah leave dengan fanfare — bilang mau inactive, minta perhatian, atau menunggu orang-orang merayu untuk tetap tinggal. Itu terlalu formal untuk UNIX.',
//       },
//     ],
//   }),
//   post({
//     id: '2',
//     slug: 'cara-jadi-afk-legend',
//     title: 'Cara Jadi AFK Legend yang Paling Ditakuti di UNIX',
//     description: 'Panduan menjadi member yang paling sering offline tapi entah kenapa paling direspek. Ini bukan jokes, ini strategi hidup.',
//     date: '2026-03-10',
//     category: 'Strategi',
//     author: 'UNIX-TEAM',
//     featured: true,
//     image: '/images/blog/cara-jadi-afk-legend.png',
//     sections: [
//       {
//         title: 'Kenapa AFK Legend Bisa Eksis?',
//         content: 'Di UNIX, ada paradoks sosial yang unik. Semakin sering kamu online, semakin kamu dianggap biasa. Semakin jarang kamu muncul, semakin aura misteriusmu terbentuk. AFK Legend adalah puncak dari paradoks ini — mereka hampir tidak pernah ada, tapi selalu terasa ada.',
//         subsections: [
//           {
//             title: 'Teori Kelangkaan',
//             content: 'Sama seperti barang langka yang harganya mahal, kehadiran yang jarang menciptakan nilai. Member yang online setiap hari jadi background noise. Member yang muncul sekali seminggu jadi event.',
//           },
//           {
//             title: 'Teori Ketidakpastian',
//             content: 'Tidak ada yang tahu kapan AFK Legend akan muncul berikutnya. Ketidakpastian ini menciptakan antisipasi. Dan setiap kemunculan terasa seperti kejadian penting, bahkan kalau yang mereka lakukan cuma bilang halo lalu pergi lagi.',
//           },
//         ],
//       },
//       {
//         title: 'Langkah-Langkah Menjadi AFK Legend',
//         content: 'Perlu dicatat: ini bukan sesuatu yang bisa dipaksakan. AFK Legend sejati tidak sedang menjalankan strategi — mereka memang natural seperti ini. Tapi kalau kamu mau mencoba, ini polanya.',
//         subsections: [
//           {
//             title: 'Kurangi Frekuensi Online Secara Gradual',
//             content: 'Jangan tiba-tiba menghilang. Kurangi pelan-pelan. Dari online setiap hari menjadi 3 hari sekali, lalu seminggu sekali. Orang-orang akan mulai notice ketiadaanmu sebelum kamu benar-benar pergi.',
//           },
//           {
//             title: 'Pastikan Setiap Kemunculan Berkesan',
//             content: 'Saat online, jangan buang waktu untuk hal-hal kecil. Masuk ke percakapan yang sedang panas, beri pendapat yang tidak terduga, lalu pergi. Jangan berlama-lama sampai momen berakhir secara alami.',
//           },
//           {
//             title: 'AFK di Momen yang Paling Dibutuhkan',
//             content: 'Ini teknik paling advance. Ketika semua orang menunggumu — saat ada keputusan penting, debat yang menggantung, atau pertanyaan yang hanya kamu bisa jawab — itulah saat yang tepat untuk offline. Biarkan notifikasi menumpuk. Kemunculanmu berikutnya akan terasa seperti kedatangan seseorang yang sangat dinantikan.',
//           },
//         ],
//       },
//       {
//         title: 'Tanda-Tanda Kamu Sudah Jadi AFK Legend',
//         content: 'Nama kamu disebut bahkan saat kamu tidak online. Orang-orang tag kamu di hal-hal yang tidak penting hanya karena ingin tahu kamu masih hidup. Dan setiap kali kamu muncul, ada setidaknya satu orang yang bilang sesuatu seperti "eh kamu masih ada?"',
//       },
//     ],
//   }),
//   post({
//     id: '3',
//     slug: 'kamus-bahasa-unix',
//     title: 'Kamus Bahasa UNIX: Panduan Ngerti Omongan Member',
//     description: 'Glossarium resmi (tidak resmi) untuk memahami bahasa komunikasi UNIX yang membingungkan, menyesatkan, dan kadang tidak masuk akal sama sekali.',
//     date: '2026-02-05',
//     category: 'Community',
//     author: 'UNIX-TEAM',
//     featured: true,
//     image: '/images/blog/kamus-bahasa-unix.png',
//     sections: [
//       {
//         title: 'Pengantar Linguistik UNIX',
//         content: 'UNIX memiliki sistem bahasa yang berkembang secara organik tanpa ada yang merancangnya. Tidak ada rapat pembahasan kosakata, tidak ada kesepakatan formal. Kata-kata muncul, dipakai semua orang, dan makna aslinya perlahan bergeser sampai tidak ada yang ingat maksud awalnya.',
//       },
//       {
//         title: 'Kosakata Dasar',
//         content: 'Kata-kata yang harus kamu pahami sebelum bisa mengikuti percakapan di UNIX.',
//         subsections: [
//           {
//             title: 'Gas',
//             content: 'Arti standar: setuju, ayo mulai. Arti UNIX: aku males tapi tidak mau keliatan males. Tingkat kepastian bahwa sesuatu akan benar-benar terjadi setelah "gas" diucapkan: sekitar 12%.',
//           },
//           {
//             title: 'Ntar',
//             content: 'Arti standar: nanti, sebentar lagi. Arti UNIX: brisik, berhenti nanya. Rentang waktu aktual dari "ntar": antara 5 menit dan tidak pernah, dengan distribusi yang sangat condong ke arah tidak pernah.',
//           },
//           {
//             title: 'Gabut',
//             content: 'Kondisi default semua member UNIX. Bukan alasan untuk tidak produktif — ini identitas. Orang yang mengaku tidak pernah gabut di UNIX dicurigai adalah bot atau salah masuk server.',
//           },
//           {
//             title: 'Nyawit',
//             content: 'Kondisi psikologis di mana seseorang terus menunggu sesuatu yang jelas tidak akan datang, tapi tetap menunggu dengan tenang dan penuh keyakinan. Berbeda dari hopium karena nyawit lebih pasif — tidak aktif berharap, hanya diam menunggu takdir.',
//           },
//         ],
//       },
//       {
//         title: 'Istilah Tingkat Lanjut',
//         content: 'Kosakata yang baru bisa dipahami setelah minimal dua minggu bergabung dan mengalaminya sendiri.',
//         subsections: [
//           {
//             title: 'Copium, Hopium, dan Delusionium',
//             content: 'Tiga sumber energi utama UNIX. Copium adalah harapan yang tahu dirinya sia-sia tapi dipelihara juga. Hopium adalah keyakinan bahwa hal mustahil tetap mungkin kalau mau sabar. Delusionium adalah ketika seseorang mengkombinasikan keduanya dan menambahkan lapisan kepercayaan diri yang sama sekali tidak berdasar. Ketiganya dianggap normal di sini.',
//           },
//           {
//             title: 'Sidang PBB',
//             content: 'Istilah untuk menggambarkan cara member UNIX mendebat topik yang sama sekali tidak penting dengan intensitas dan keseriusan seperti negosiasi perdamaian internasional. Topik yang pernah jadi sidang PBB antara lain: apakah mie instan lebih enak dimasak atau diseduh, dan siapa yang paling benar soal build karakter yang jelas-jelas semua salah.',
//           },
//           {
//             title: 'Silent Leave',
//             content: 'Tindakan meninggalkan server atau percakapan tanpa pemberitahuan apapun. Di komunitas lain ini mungkin dianggap kasar. Di UNIX ini adalah norma yang dihormati. Bahkan ada yang bilang silent leave adalah satu-satunya cara keluar yang bermartabat.',
//           },
//         ],
//       },
//     ],
//   }),
//   post({
//     id: '4',
//     slug: 'sejarah-rivalri-katspoll',
//     title: 'Sejarah Legendaris Rivalri UNIX vs @katspoll',
//     description: 'Dokumentasi tidak resmi tentang perjalanan panjang bully-membully yang membentuk identitas UNIX dan melahirkan seorang NPC legendaris.',
//     date: '2026-01-28',
//     category: 'Lore',
//     author: 'UNIX-TEAM',
//     featured: false,
//     image: '/images/blog/sejarah-rivalri-katspoll.png',
//     sections: [
//       {
//         title: 'Catatan Sejarawan',
//         content: 'Artikel ini ditulis berdasarkan kesaksian kolektif member UNIX yang ingatannya tidak selalu akurat karena sebagian besar kejadian berlangsung di sela-sela sesi gaming dan debat tidak penting. Beberapa detail mungkin dilebih-lebihkan secara tidak sengaja. Tapi spiritnya akurat.',
//       },
//       {
//         title: 'Asal Usul yang Tidak Jelas',
//         content: 'Tidak ada yang bisa menunjuk satu momen spesifik sebagai awal dari tradisi ini. Yang pasti, @katspoll sudah ada sejak awal komunitas terbentuk, dan tradisi bullynya tumbuh secara organik tanpa ada yang merancang.',
//         subsections: [
//           {
//             title: 'Hipotesis Pertama',
//             content: 'Ada yang berpendapat tradisi ini dimulai karena @katspoll pernah mengeluarkan pendapat yang kontroversial di awal-awal komunitas berdiri. Tidak ada yang ingat pendapatnya apa, tapi konsekuensinya bertahan sampai sekarang.',
//           },
//           {
//             title: 'Hipotesis Kedua',
//             content: 'Ada yang percaya tidak ada pemicu spesifik. @katspoll hanya ada di tempat yang tepat pada waktu yang salah, dan momentum terbentuk sendiri. Ini mungkin penjelasan yang paling masuk akal.',
//           },
//         ],
//       },
//       {
//         title: 'Evolusi Status: Dari Korban ke Legenda',
//         content: 'Yang menarik dari kisah @katspoll bukan bullying-nya — itu hal biasa. Yang menarik adalah bagaimana dia berevolusi dari target menjadi karakter sentral komunitas.',
//         subsections: [
//           {
//             title: 'Fase 1: Korban Biasa',
//             content: 'Tahap awal. Dibulli karena baru dan ada. Reaksinya tidak berlebihan, tidak drama, dan itu membuatnya menjadi target yang aman sekaligus membosankan untuk ditinggalkan. Bertahan di fase ini lebih lama dari rata-rata orang.',
//           },
//           {
//             title: 'Fase 2: Target Favorit',
//             content: 'Setelah cukup lama survive, @katspoll mulai punya "fanbase bully" sendiri. Member baru yang join secara otomatis diperkenalkan ke tradisi ini sebagai bagian dari onboarding tidak resmi.',
//           },
//           {
//             title: 'Fase 3: NPC Legendaris',
//             content: 'Status tertinggi yang bisa dicapai seseorang di UNIX tanpa menjadi Popol. NPC Legendaris adalah karakter yang sudah menjadi bagian dari DNA komunitas. Kehadirannya memberi struktur pada kekacauan yang ada.',
//           },
//         ],
//       },
//       {
//         title: 'Status Terkini dan Proyeksi Masa Depan',
//         content: 'Tradisi masih berlanjut, @katspoll masih ada, dan tidak ada tanda-tanda perubahan dalam waktu dekat. Ini mungkin adalah hubungan paling konsisten yang pernah ada di UNIX — di antara semua hal yang tidak pernah selesai dan tidak pernah jelas, setidaknya ini stabil.',
//       },
//     ],
//   }),
//   post({
//     id: '5',
//     slug: 'mabar-pembubaran-unix',
//     title: 'Mabar Pembubaran UNIX: Foto Bareng 6 Jam, Satu Baris Pun Belum Lurus',
//     description: 'Dokumentasi resmi sesi mabar terakhir UNIX yang harusnya penuh haru tapi berakhir jadi rekaman terlengkap tentang bagaimana jaringan bisa menghancurkan segalanya.',
//     date: '2026-05-09',
//     category: 'Chaos',
//     author: 'UNIX-TEAM',
//     featured: true,
//     image: '/images/blog/mabar-pembubaran-unix.jpg',
//     sections: [
//       {
//         title: 'Latar Belakang yang Tidak Perlu Tapi Tetap Ada',
//         content: 'Mabar Pembubaran UNIX dijadwalkan mulai jam 8 malam. Konsepnya sederhana: main bareng satu sesi terakhir, foto bareng, selesai. Tidak ada yang menduga bahwa kata "sederhana" di kalimat sebelumnya adalah kesalahan fatal terbesar dalam sejarah komunitas ini.',
//       },
//       {
//         title: 'Babak Pertama: Kena Petir Sebelum Main',
//         content: 'Jam 7:58, dua menit sebelum jadwal, sambaran petir menghantam tiang listrik di dekat rumah salah satu member. Router-nya mati. Bukan metafora, bukan dramatis, benar-benar mati. Ada asap. Member tersebut masih sempat kirim pesan "bro router aku" sebelum hilang dari voice untuk 20 menit berikutnya.',
//         subsections: [
//           {
//             title: 'Korban Jaringan Berikutnya',
//             content: 'Empat menit setelah insiden petir, dua member lain disconnect tanpa sebab yang jelas. Tidak ada petir di lokasi mereka. Tidak ada gangguan listrik. Sinyalnya hanya memutus sendiri karena memang begitulah sifatnya — tidak butuh alasan, tidak butuh momen dramatis, cukup pergi begitu saja seperti mantan yang ga ada chemistry-nya.',
//           },
//           {
//             title: 'Proses Reconnect yang Berlangsung 47 Menit',
//             content: 'Total waktu yang dihabiskan untuk menunggu semua orang bisa join sebelum main dimulai adalah 47 menit. Proses ini melibatkan dua restart modem, satu kejadian cabut-colok kabel yang tidak perlu diceritakan lebih lanjut, dan tiga kali ganti server karena yang pertama lagnya tidak manusiawi, yang kedua lebih buruk, dan yang ketiga entah kenapa sudah tidak bisa diakses padahal baru dipakai kemarin.',
//           },
//         ],
//       },
//       {
//         title: 'Babak Kedua: Sesi Foto Bareng Dimulai',
//         content: 'Setelah main beberapa ronde yang hasilnya tidak perlu didokumentasikan, tibalah sesi yang paling ditunggu: foto bareng. Rencananya cepat. Baris, screenshot, selesai. Kenyataannya berbeda secara signifikan.',
//         subsections: [
//           {
//             title: 'Percobaan Pertama sampai Kesepuluh',
//             content: 'Dari sepuluh percobaan pertama, tidak satu pun menghasilkan foto yang bisa dipakai. Alasannya bervariasi: ada yang masih loading, ada yang karakternya jongkok sendiri tanpa input, ada yang disconnect tepat saat semua orang sudah siap, dan ada yang entah bagaimana berhasil berdiri di tengah-tengah orang lain padahal seharusnya tidak mungkin secara spasial.',
//           },
//           {
//             title: 'Percobaan Kesebelas sampai Ketiga Puluh Satu',
//             content: 'Polanya tidak membaik. Dari 31 total percobaan yang tercatat, 14 gagal karena ada yang tertinggal di spawn, 7 karena salah arah hadap kamera, 5 karena ada yang posisinya tidak pernah bisa lurus dengan siapapun di sekitarnya meski sudah diulang berkali-kali, 3 karena ada yang tiba-tiba emote tanpa koordinasi, 2 karena lag menggeser kamera di momen paling penting, dan 1 karena salah satu karakter terbang ke atas secara vertikal tanpa pernah kembali. Member yang karakternya terbang tersebut tidak bisa menjelaskan kenapa. Kami juga tidak bisa.',
//           },
//         ],
//       },
//       {
//         title: 'Babak Ketiga: Jaringan sebagai Antagonis Utama',
//         content: 'Di antara semua kekacauan yang terjadi, satu hal yang konsisten adalah disconnect. Setiap kali ada yang bilang "oke semua siap?", dalam radius tiga detik seseorang pasti terputus. Ini terjadi cukup sering sampai kalimat tersebut mulai dihindari secara kolektif. Kita coba ganti kata-katanya. Tidak membantu. Kita coba diam dan langsung screenshot. Tetap ada yang disconnect. Pada titik ini ada yang menyarankan bahwa mungkin masalahnya bukan jaringan, tapi kalimat itu sendiri yang dikutuk. Tidak ada yang menyanggah teori ini.',
//         subsections: [
//           {
//             title: 'Pindah Server Sebanyak Tiga Kali',
//             content: 'Dalam upaya mengatasi masalah koneksi, kita pindah server. Hasilnya sama. Pindah lagi, lebih buruk. Pindah ke server ketiga, kondisinya tidak lebih baik dari server pertama. Mencoba kembali ke server pertama, server tersebut sudah tidak bisa diakses. Tidak ada notifikasi, tidak ada penjelasan, hanya tidak bisa dibuka.',
//           },
//           {
//             title: 'Member yang Disconnect Paling Banyak',
//             content: 'Orang yang terkena petir di awal acara tercatat disconnect sebanyak tujuh kali dalam satu sesi. Ini menjadi rekor tidak resmi yang mungkin tidak akan ada yang sengaja berusaha melampaui. Setiap kali dia berhasil masuk, ada jeda sekitar dua menit sebelum dia terputus lagi. Pola ini sangat konsisten sampai beberapa orang mulai menghitung dan bertaruh kapan disconnect berikutnya terjadi.',
//           },
//         ],
//       },
//       {
//         title: 'Akhir yang Tidak Dramatis Sama Sekali',
//         content: 'Jam 3 pagi, setelah kurang lebih enam jam, foto bareng resmi dinyatakan belum selesai dan ditunda tanpa tanggal yang jelas. Bukan karena menyerah, tapi karena ada yang harus bangun jam 6. Yang tersisa dari seluruh sesi ini adalah 47 screenshot gagal, beberapa rekaman layar yang blur di bagian paling penting, dan satu foto di mana hanya dua dari dua belas orang yang seharusnya ada bisa terlihat. Sisanya tidak ada di frame, tidak ada penjelasan kenapa, dan tidak ada yang cukup peduli untuk menyelidikinya lebih lanjut. Foto finalnya belum ada sampai artikel ini ditulis. Kemungkinan besar tidak akan pernah ada.',
//       },
//     ],
//   }),
// ];